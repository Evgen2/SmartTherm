Esptool.py Documentation      https://docs.espressif.com/projects/esptool/en/latest/esp32/ 
Install esptool (Python)  on Windows 11 https://www.youtube.com/watch?v=3Wi0L4pACmM

ESPTOOL Executable (Windows, MacOs and Linux)  https://github.com/espressif/esptool/releases